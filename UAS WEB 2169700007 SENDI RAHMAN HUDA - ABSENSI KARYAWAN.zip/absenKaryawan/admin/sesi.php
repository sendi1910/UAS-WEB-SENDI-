<?php 
	
	if (empty($_SESSION['idabsen']) AND empty($_SESSION['idabsen'])) {
		header("location: login.php");
	}
	


 ?>