<?php 
session_start();
unset($_SESSION['idabsen2']);
header("location: ../");
 ?>